
import os
import math
import numpy as np
import random
from itertools import permutations
import time as t

#Getting the path of the python file
dirpath = os.path.dirname(__file__)
file_list=[]
file_name=[]

start=t.clock()
# Walking CSV file of the dirpath  4and storing them as an array
for root,dirs,files in os.walk(dirpath):
    for file in files:
       if file.endswith(".txt"):
           len_filename=len(file)
           file_name.append(file[:len_filename-4])
           x= os.path.join(dirpath, file)
           file1 = open(x, 'r')
           y = file1.read().split()
           file_list.append(y)

# Creating a dictionary which has key as a file names and value is the array of the file content
dic_files=dict(zip(file_name,file_list))


#Creating list of words and document indices :
doc_ind=[]
word_ind=[]
D=len(dic_files.keys())
K=2

for keys in dic_files.keys():
    for i in range(len(dic_files[keys])):
        doc_ind.append(int(keys))
        word_ind.append(dic_files[keys][i])

#total number of words
Nword=len(word_ind)

#Generating array initial topics indices
rand_top=[]
for i in range (Nword):
    rand_top.append(random.randrange(0, 2, 1))

#cd matrix
cd=np.zeros((D,K))
for i in range(len(doc_ind)):
    for j in range(len(rand_top)):
        if i==j:
            cd[doc_ind[i]-1,[rand_top[j]]]+=1

#kVmatrix
V=list(set(word_ind))
V_dic=dict(zip(V,range(len(V))))
print(V_dic)
ct=np.zeros((K,len(V)))
for i in range(len(rand_top)):
    for j in range(len(word_ind)):
        if i==j:
            ct[rand_top[i],V_dic[word_ind[i]]]+=1


#Pmatrix
p=np.zeros((1,K))

#permutation p(n)
n=list(range(Nword))
per_n=np.random.permutation(n)
list_per=per_n.tolist()
for i in range(5000):
    for j in list_per:
        word_i=word_ind[j]
        topic_i = rand_top[j]
        doc_i = doc_ind[j]
        cd[doc_i - 1][topic_i] =cd[doc_i - 1][topic_i] - 1
        ct[topic_i][V_dic[word_i]]=ct[topic_i][V_dic[word_i]]-1
        for i in range(0,K):
            alpha=5.0/K
            beta=0.01
            # exp0=(ct[i][V_dic[word_i]]+beta)
            # exp1=(len(V)*beta+sum(ct[i]))
            exp1=(ct[i][V_dic[word_i]]+beta)/(len(V)*beta+np.sum(ct[i]))
            exp2=(cd[doc_i-1][i]+alpha)/(K*alpha+np.sum(cd[doc_i-1]))
            p[0][i]=exp1*exp2

        sum=np.sum(p,axis=1)
        P_norm=p/sum
        P_list= [item for sublist in P_norm.tolist() for item in sublist]
        rand_top[j]=np.random.choice(list(set(rand_top)), 1, p=P_list)[0]
        cd[doc_i-1][rand_top[j]]=cd[doc_i-1][rand_top[j]]+1
        ct[rand_top[j]][V_dic[word_i]]=ct[rand_top[j]][V_dic[word_i]]+1

print(ct)
print(t.clock()-start)
























